package test;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import entities.Autos;
import entities.Motos;
import entities.Vehiculo;

public class TestLaboratorio2 {

    public static void main(String[] args) {

        List<Vehiculo> list = new ArrayList();
        System.out.println("lista de vehiculos: ");
        list.add(new Autos("Peugeot", "206", "4", 200000.00));
        list.add(new Motos("Honda", "Titan", "150c", 60000.00));
        list.add(new Autos("Peugeot", "208", "5", 250000.00));
        list.add(new Motos("Yamaha", "YBR", "125c", 80500.50));
        list.stream().forEach(System.out::println);

        System.out.println("**********************************");

        vehiculoMasCaro(list);

        System.out.println("**********************************");

        vehiculoMasBarato(list);

        System.out.println("**********************************");

        vehiculoconletraY(list);

        System.out.println("**********************************");

        vehiculoMayoraMenor(list);

        System.out.println("**********************************");

        ordenNatural(list);

        System.out.println("**********************************");

    }



    private static void vehiculoconletraY(List<Vehiculo> list) {
        System.out.println("vehiculo q contiene la letra y");
        list
                .stream()
                .filter(v -> v.getModelo().contains("Y"))
                .forEach(v -> System.out.println(v.getMarca()+" "+v.getModelo()+" "+v.getPrecio()));
    }

    private static void vehiculoMasBarato(List<Vehiculo> list) {
        Vehiculo vehiculoMasbarato = list
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        System.out
                .println("vehiculo mas barato: " + vehiculoMasbarato.getMarca() + " " + vehiculoMasbarato.getModelo());
    }

    private static void vehiculoMasCaro(List<Vehiculo> list) {
        Vehiculo vehiculoMascaro = list
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        System.out.println("vehiculo mas caro: " + vehiculoMascaro.getMarca() + " " + vehiculoMascaro.getModelo());
    }

    private static void vehiculoMayoraMenor(List<Vehiculo> list) {
        System.out.println("vehiculos de mayor a menor");
        list
                .stream()
                .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
                .forEach(System.out::println);
    }

    private static void ordenNatural(List<Vehiculo> list) {
        System.out.println("orden natural");
        list
        .stream()
        .sorted()
        .forEach(System.out::println);
    }
    

}
