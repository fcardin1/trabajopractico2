package entities;

public class Autos extends Vehiculo {

    private String puertas;

    public Autos(String marca, String modelo, String puertas, double precio) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    public String getPuertas() {
        return puertas;
    }

    @Override
    
    public String toString() {
        return " Marca:" + super.getMarca()+"//" + " Modelo:" + super.getModelo()+"//"  + "Puertas:" + getPuertas()+"//" +
                 " Precio:" +"$"+ getPrecioFormat() + "";
    }

}