package entities;

public class Motos extends Vehiculo {
   
    private String cilindrada;

    
    public Motos(String marca, String modelo, String cilindrada, double precio) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }


    public String getCilindrada() {
        return cilindrada;
    }


    @Override
    
    public String toString() {
        return " Marca:" + super.getMarca()+"//" + " Modelo:" + super.getModelo()+"//"  + "Cilindrada:" + getCilindrada()+"//" +
                 " Precio:" +"$"+ getPrecioFormat() + "";
    }

}
